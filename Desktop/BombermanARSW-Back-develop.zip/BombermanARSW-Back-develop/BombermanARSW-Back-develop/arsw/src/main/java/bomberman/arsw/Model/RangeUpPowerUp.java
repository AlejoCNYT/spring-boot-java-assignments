package bomberman.arsw.Model;

public class RangeUpPowerUp {
}
