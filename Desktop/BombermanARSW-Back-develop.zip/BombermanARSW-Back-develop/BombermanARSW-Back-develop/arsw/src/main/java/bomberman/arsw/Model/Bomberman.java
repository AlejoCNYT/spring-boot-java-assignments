package bomberman.arsw.Model;

import java.util.List;

public class Bomberman {
    private List<Player> players;
    private GameMap gameMap;
    private boolean gameOver;
}
