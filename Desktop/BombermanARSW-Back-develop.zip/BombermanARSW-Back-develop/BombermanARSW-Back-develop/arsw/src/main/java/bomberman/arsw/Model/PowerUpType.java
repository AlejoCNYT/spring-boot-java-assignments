package bomberman.arsw.Model;

public enum PowerUpType {
    LIFE_UP,       // Aumenta vida
    BOMB_UP,       // Aumenta número de bombas
    FIRE_UP,       // Aumenta rango de explosión
    SPEED_UP,      // Aumenta velocidad
    WALL_PASS,     // Permite atravesar paredes
    INVINCIBILITY,
    FIRE_PLUS
}