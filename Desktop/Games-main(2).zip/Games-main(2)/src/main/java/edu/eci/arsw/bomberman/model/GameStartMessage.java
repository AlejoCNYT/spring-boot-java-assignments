package edu.eci.arsw.bomberman.model;

public class GameStartMessage {
    private String gameCode;

    public String getGameCode() {
        return gameCode;
    }

    public void setGameCode(String gameCode) {
        this.gameCode = gameCode;
    }
}
