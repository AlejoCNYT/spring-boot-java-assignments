import React from 'react';

const PowerupInvincible = () => {
  return (
    <img
      src="C:\Users\usuario\Desktop\BombermanARSW-Front-develop\BombermanARSW-Front-develop\my-app\src\images\powerup2.png"
      alt="Invincibility Power-Up"
      style={{ width: '20px', height: '20px' }}
    />
  );
};

export default PowerupInvincible;
