import React, { useEffect, useState } from 'react';
import './Explosion.css';

interface ExplosionProps {
  x: number;
  y: number;
  range: number;
  onComplete: () => void;
}

const Explosion: React.FC<ExplosionProps> = ({ x, y, range, onComplete }) => {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    console.log(`🔍 Renderizando explosión en (${x}, ${y}), rango ${range}`);
    const timer = setTimeout(() => {
      setVisible(false);
      onComplete();
    }, 500);
    return () => clearTimeout(timer);
  }, [x, y, range, onComplete]);

  if (!visible) return null;

  // Desplazamientos en las cuatro direcciones
  const offsets = [
    { dx: 1, dy: 0 },
    { dx: -1, dy: 0 },
    { dx: 0, dy: 1 },
    { dx: 0, dy: -1 },
  ];

  return (
    <>
      {/* Centro de la explosión */}
      <div
        className="explosion-center"
        style={{
          left: `${x * 32}px`,
          top:  `${y * 32}px`,
        }}
      />
      {/* Brazos de la explosión según el rango y direcciones */}
      {Array.from({ length: range }).flatMap((_, i) =>
        offsets.map(({ dx, dy }, idx) => (
          <div
            key={`${i}-${idx}`}
            className="explosion-direction"
            style={{
              left: `${(x + dx * (i + 1)) * 32}px`,
              top:  `${(y + dy * (i + 1)) * 32}px`,
            }}
          />
        ))
      )}
    </>
  );
};

export default Explosion;
